pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "CarMusic"

// App de la pantalla del coche  -> CarMusic.apk
include(":carmusic")
// App del teléfono              -> CarMusic-Companion.apk
include(":companion")
