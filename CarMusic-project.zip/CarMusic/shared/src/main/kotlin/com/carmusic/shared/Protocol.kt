package com.carmusic.shared

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.util.UUID

/**
 * Protocolo entre CarMusic Companion (teléfono) y CarMusic (pantalla) sobre Bluetooth RFCOMM.
 *
 * RFCOMM es un flujo de bytes fiable y ordenado, así que basta con tramas con longitud:
 *
 *   [tipo: 1 byte][longitud: 4 bytes][contenido]
 *
 * Teléfono -> pantalla: HELLO, META, ART.   Pantalla -> teléfono: CMD.
 * Este archivo lo compilan las dos apps (carpeta `shared`).
 */
object Protocol {
    /** UUID propio del servicio. El servidor RFCOMM (pantalla) lo publica por SDP. */
    val SERVICE_UUID: UUID = UUID.fromString("7b1f5a0e-4c2d-4f0a-9d3e-5c0a4d2b1e90")
    const val SERVICE_NAME = "CarMusic"
    const val VERSION = 1

    const val T_HELLO = 1
    const val T_META = 2
    const val T_ART = 3
    const val T_CMD = 4

    const val CMD_PLAY = 1
    const val CMD_PAUSE = 2
    const val CMD_TOGGLE = 3
    const val CMD_NEXT = 4
    const val CMD_PREV = 5

    /** Tamaño máximo de una trama (protección ante datos corruptos). */
    const val MAX_FRAME = 1_000_000

    /** Carátula: lado mayor máximo y calidad JPEG. Con 512 px y 80 % pesa unos 30-70 KB. */
    const val ART_MAX_PX = 512
    const val ART_JPEG_QUALITY = 80

    const val YTM_PACKAGE = "com.google.android.apps.youtube.music"

    fun hello(deviceName: String): ByteArray {
        val bos = ByteArrayOutputStream()
        val d = DataOutputStream(bos)
        d.writeByte(VERSION)
        d.writeUTF(if (deviceName.length > 100) deviceName.substring(0, 100) else deviceName)
        d.flush()
        return bos.toByteArray()
    }

    fun encodeArt(key: Int, jpeg: ByteArray): ByteArray {
        val bos = ByteArrayOutputStream(jpeg.size + 4)
        val d = DataOutputStream(bos)
        d.writeInt(key)
        d.write(jpeg)
        d.flush()
        return bos.toByteArray()
    }

    fun decodeArtKey(payload: ByteArray): Int {
        if (payload.size < 4) throw IOException("Carátula demasiado corta")
        return DataInputStream(ByteArrayInputStream(payload)).readInt()
    }

    fun decodeArtBytes(payload: ByteArray): ByteArray {
        if (payload.size < 4) throw IOException("Carátula demasiado corta")
        return payload.copyOfRange(4, payload.size)
    }
}

/** Una trama recibida. */
class Frame(val type: Int, val payload: ByteArray)

object FrameIO {
    /** Escribe una trama; el contenido se envía en fragmentos de 4 KB. */
    fun write(out: DataOutputStream, type: Int, payload: ByteArray) {
        synchronized(out) {
            out.writeByte(type)
            out.writeInt(payload.size)
            var off = 0
            while (off < payload.size) {
                val n = minOf(4096, payload.size - off)
                out.write(payload, off, n)
                off += n
            }
            out.flush()
        }
    }

    fun read(input: DataInputStream): Frame {
        val type = input.readUnsignedByte()
        val len = input.readInt()
        if (len < 0 || len > Protocol.MAX_FRAME) throw IOException("Trama inválida: longitud $len")
        val buf = ByteArray(len)
        input.readFully(buf)
        return Frame(type, buf)
    }
}

/** Estado de reproducción que el teléfono describe a la pantalla. */
data class Meta(
    /** false = el teléfono no tiene ninguna sesión multimedia con canción. */
    val hasSession: Boolean,
    val playing: Boolean,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    /** Posición en el momento del envío; la pantalla la extrapola mientras suene. */
    val positionMs: Long,
    /** Identifica la canción; la carátula (ART) lleva la misma clave. */
    val trackKey: Int,
    val sourcePackage: String
) {
    fun encode(): ByteArray {
        val bos = ByteArrayOutputStream()
        val d = DataOutputStream(bos)
        d.writeByte(Protocol.VERSION)
        d.writeBoolean(hasSession)
        d.writeBoolean(playing)
        d.writeUTF(clip(title))
        d.writeUTF(clip(artist))
        d.writeUTF(clip(album))
        d.writeLong(durationMs)
        d.writeLong(positionMs)
        d.writeInt(trackKey)
        d.writeUTF(clip(sourcePackage))
        d.flush()
        return bos.toByteArray()
    }

    companion object {
        private fun clip(s: String): String = if (s.length > 300) s.substring(0, 300) else s

        fun decode(bytes: ByteArray): Meta {
            val d = DataInputStream(ByteArrayInputStream(bytes))
            val ver = d.readUnsignedByte()
            if (ver != Protocol.VERSION) throw IOException("Versión de protocolo no soportada: $ver")
            val hasSession = d.readBoolean()
            val playing = d.readBoolean()
            val title = d.readUTF()
            val artist = d.readUTF()
            val album = d.readUTF()
            val duration = d.readLong()
            val position = d.readLong()
            val key = d.readInt()
            val pkg = d.readUTF()
            return Meta(hasSession, playing, title, artist, album, duration, position, key, pkg)
        }

        fun keyOf(title: String, artist: String, album: String, durationMs: Long): Int =
            (title + "\u0001" + artist + "\u0001" + album + "\u0001" + durationMs).hashCode()
    }
}
