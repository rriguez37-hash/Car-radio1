package com.carmusic.player

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.util.Log
import com.carmusic.shared.Meta

/**
 * Servicio de la pantalla. Es un NotificationListenerService porque Android solo deja a una app normal
 * leer las sesiones multimedia (MediaSessionManager.getActiveSessions) si tiene uno habilitado.
 * No lee notificaciones.
 *
 * Hace dos cosas:
 *  1. Sigue la sesión AVRCP (`com.android.bluetooth`) y la vuelca en [PlayerModel].
 *  2. Ejecuta el servidor RFCOMM que recibe metadatos y carátula del teléfono.
 */
class CarService : NotificationListenerService() {

    private val main = Handler(Looper.getMainLooper())
    private var msm: MediaSessionManager? = null
    private var me: ComponentName? = null
    private var controller: MediaController? = null
    private var token: MediaSession.Token? = null
    private var server: LinkServer? = null
    private var listenerRegistered = false

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) {
            pushAvrcp()
        }

        override fun onPlaybackStateChanged(state: PlaybackState?) {
            pushAvrcp()
        }

        override fun onSessionDestroyed() {
            pickSession()
        }
    }

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { pickSession() }

    private val linkCallbacks = object : LinkServer.Callbacks {
        override fun onListening(listening: Boolean, error: String?) {
            PlayerModel.post { PlayerModel.setListening(listening, error) }
        }

        override fun onConnected(deviceName: String?) {
            PlayerModel.post { PlayerModel.setLinkConnected(true, deviceName) }
        }

        override fun onDisconnected() {
            PlayerModel.post { PlayerModel.setLinkConnected(false, null) }
        }

        override fun onMeta(meta: Meta) {
            PlayerModel.post { PlayerModel.setLinkMeta(meta) }
        }

        override fun onArt(key: Int, jpeg: ByteArray) {
            // La decodificación se hace aquí (hilo de Bluetooth), no en el principal.
            val bmp: Bitmap? = try {
                BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size)
            } catch (e: Exception) {
                Log.e(TAG, "Carátula recibida no decodificable", e)
                null
            }
            PlayerModel.post { PlayerModel.setLinkArt(key, bmp, jpeg.size) }
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        Log.i(TAG, "CarService conectado")
        msm = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        me = ComponentName(this, CarService::class.java)
        PlayerModel.serviceConnected = true

        val m = msm
        val c = me
        if (m != null && c != null && !listenerRegistered) {
            try {
                m.addOnActiveSessionsChangedListener(sessionsListener, c, main)
                listenerRegistered = true
            } catch (e: Exception) {
                Log.e(TAG, "No se pudo escuchar las sesiones multimedia", e)
            }
        }
        pickSession()

        if (server == null) {
            val s = LinkServer(linkCallbacks) { Prefs(applicationContext).insecureLink }
            server = s
            PlayerModel.linkServer = s
            s.start()
        }
        PlayerModel.notifyChanged()
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        Log.w(TAG, "CarService desconectado")
        teardown()
        if (Build.VERSION.SDK_INT >= 24) {
            val c = me
            if (c != null) {
                try {
                    requestRebind(c)
                } catch (e: Exception) {
                    Log.e(TAG, "requestRebind falló", e)
                }
            }
        }
    }

    override fun onDestroy() {
        teardown()
        super.onDestroy()
    }

    private fun teardown() {
        try {
            controller?.unregisterCallback(callback)
        } catch (e: Exception) {
            // ya estaba desregistrado
        }
        controller = null
        token = null
        if (listenerRegistered) {
            try {
                msm?.removeOnActiveSessionsChangedListener(sessionsListener)
            } catch (e: Exception) {
                Log.e(TAG, "Error quitando el listener de sesiones", e)
            }
            listenerRegistered = false
        }
        server?.stop()
        server = null
        PlayerModel.post {
            PlayerModel.serviceConnected = false
            PlayerModel.linkServer = null
            PlayerModel.avrcpController = null
            PlayerModel.setLinkConnected(false, null)
            PlayerModel.setListening(false, "Servicio detenido")
            PlayerModel.setAvrcp(null, null, null)
        }
    }

    // ---------------------------------------------------------------- AVRCP

    private fun pickSession() {
        val m = msm
        val c = me
        if (m == null || c == null) return
        val list: List<MediaController> = try {
            m.getActiveSessions(c)
        } catch (e: Exception) {
            Log.e(TAG, "Error en getActiveSessions", e)
            emptyList()
        }
        // La sesión del stack Bluetooth del sistema: es la que refleja lo que reproduce el teléfono.
        var chosen: MediaController? = list.firstOrNull { it.packageName == BT_PACKAGE }
        if (chosen == null) {
            chosen = list.firstOrNull { it.packageName.contains("bluetooth", ignoreCase = true) }
        }
        val newToken = chosen?.sessionToken
        if (newToken != token) {
            try {
                controller?.unregisterCallback(callback)
            } catch (e: Exception) {
                // ya estaba desregistrado
            }
            controller = chosen
            token = newToken
            if (chosen != null) {
                try {
                    chosen.registerCallback(callback, main)
                } catch (e: Exception) {
                    Log.e(TAG, "No se pudo observar ${chosen.packageName}", e)
                }
            }
            PlayerModel.avrcpController = chosen
        }
        pushAvrcp()
    }

    private fun pushAvrcp() {
        val c = controller
        if (c == null) {
            PlayerModel.setAvrcp(null, null, null)
            return
        }
        val md: MediaMetadata? = try {
            c.metadata
        } catch (e: Exception) {
            Log.e(TAG, "Error leyendo metadata", e)
            null
        }
        val st: PlaybackState? = try {
            c.playbackState
        } catch (e: Exception) {
            Log.e(TAG, "Error leyendo estado", e)
            null
        }

        var track: PlayerModel.Track? = null
        var art: Bitmap? = null
        if (md != null) {
            val title = md.getString(MediaMetadata.METADATA_KEY_TITLE)
                ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
                ?: ""
            if (title.isNotBlank()) {
                val artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
                    ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                    ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
                    ?: ""
                val album = md.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""
                val duration = md.getLong(MediaMetadata.METADATA_KEY_DURATION)

                val now = SystemClock.elapsedRealtime()
                var pos = st?.position ?: 0L
                if (pos < 0L) pos = 0L
                var stamp = st?.lastPositionUpdateTime ?: now
                if (stamp <= 0L) stamp = now
                val rawSpeed = st?.playbackSpeed ?: 1f
                val speed = if (rawSpeed <= 0f) 1f else rawSpeed
                val playing = st?.state == PlaybackState.STATE_PLAYING

                track = PlayerModel.Track(title, artist, album, duration, pos, stamp, speed, playing, "AVRCP")
            }
            // En esta unidad el AVRCP no trae carátula, pero se aprovecha si algún día la trae.
            art = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        }
        PlayerModel.setAvrcp(c.packageName, track, art)
    }

    private companion object {
        const val TAG = "CarMusic"
        const val BT_PACKAGE = "com.android.bluetooth"
    }
}
