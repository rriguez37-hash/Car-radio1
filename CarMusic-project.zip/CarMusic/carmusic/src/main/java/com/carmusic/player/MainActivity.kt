package com.carmusic.player

import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.util.Log
import android.util.TypedValue
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import com.carmusic.shared.Protocol

/**
 * Pantalla del reproductor. Minimalista: carátula a la izquierda; título, artista, álbum,
 * progreso y controles a la derecha; indicador de conexión arriba a la derecha.
 */
class MainActivity : Activity(), PlayerModel.Listener {

    private lateinit var prefs: Prefs
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var content: LinearLayout
    private lateinit var artHolder: View
    private lateinit var ivArt: RoundedSquareImageView
    private lateinit var tvTitle: TextView
    private lateinit var tvArtist: TextView
    private lateinit var tvAlbum: TextView
    private lateinit var tvPos: TextView
    private lateinit var tvDur: TextView
    private lateinit var progress: ProgressBar
    private lateinit var btnPrev: ImageButton
    private lateinit var btnPlay: ImageButton
    private lateinit var btnNext: ImageButton
    private lateinit var btnMenu: ImageButton
    private lateinit var tvStatus: TextView

    // Para no redibujar lo que no cambió
    private var shownTitle: String? = null
    private var shownArtist: String? = null
    private var shownAlbum: String? = null
    private var shownArt: Bitmap? = null
    private var shownPlaying: Boolean? = null
    private var shownStatus: String? = null
    private var titleIsPlaceholder = false

    private val ticker = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, 500L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)

        content = findViewById(R.id.content)
        artHolder = findViewById(R.id.artHolder)
        ivArt = findViewById(R.id.ivArt)
        tvTitle = findViewById(R.id.tvTitle)
        tvArtist = findViewById(R.id.tvArtist)
        tvAlbum = findViewById(R.id.tvAlbum)
        tvPos = findViewById(R.id.tvPos)
        tvDur = findViewById(R.id.tvDur)
        progress = findViewById(R.id.progress)
        btnPrev = findViewById(R.id.btnPrev)
        btnPlay = findViewById(R.id.btnPlay)
        btnNext = findViewById(R.id.btnNext)
        btnMenu = findViewById(R.id.btnMenu)
        tvStatus = findViewById(R.id.tvStatus)

        scaleUi()

        btnPrev.setOnClickListener { PlayerModel.sendCommand(Protocol.CMD_PREV) }
        btnNext.setOnClickListener { PlayerModel.sendCommand(Protocol.CMD_NEXT) }
        btnPlay.setOnClickListener { PlayerModel.sendCommand(Protocol.CMD_TOGGLE) }
        btnMenu.setOnClickListener { showSettings() }
        tvStatus.setOnClickListener { showDiagnostics() }
    }

    override fun onStart() {
        super.onStart()
        PlayerModel.addListener(this)
        // Si el acceso está concedido pero el servicio no está enlazado, se pide al sistema que lo reenlace.
        if (isListenerEnabled() && !PlayerModel.serviceConnected && Build.VERSION.SDK_INT >= 24) {
            try {
                NotificationListenerService.requestRebind(ComponentName(this, CarService::class.java))
            } catch (e: Exception) {
                Log.e(TAG, "requestRebind falló", e)
            }
        }
        render()
    }

    override fun onResume() {
        super.onResume()
        applyWindow()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    override fun onStop() {
        PlayerModel.removeListener(this)
        super.onStop()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyWindow()
    }

    override fun onModelChanged() {
        render()
    }

    // ---------------------------------------------------------------- ventana

    @Suppress("DEPRECATION")
    private fun applyWindow() {
        if (prefs.keepOn) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        window.decorView.systemUiVisibility = if (prefs.fullscreen) {
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        } else {
            View.SYSTEM_UI_FLAG_VISIBLE
        }
    }

    /** Tamaños proporcionales al lado menor de la pantalla: sirve igual en cualquier resolución. */
    private fun scaleUi() {
        val dm = resources.displayMetrics
        val base = minOf(dm.widthPixels, dm.heightPixels).toFloat()

        tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_PX, base * 0.075f)
        tvArtist.setTextSize(TypedValue.COMPLEX_UNIT_PX, base * 0.052f)
        tvAlbum.setTextSize(TypedValue.COMPLEX_UNIT_PX, base * 0.042f)
        tvPos.setTextSize(TypedValue.COMPLEX_UNIT_PX, base * 0.034f)
        tvDur.setTextSize(TypedValue.COMPLEX_UNIT_PX, base * 0.034f)
        tvStatus.setTextSize(TypedValue.COMPLEX_UNIT_PX, base * 0.032f)

        val pad = (base * 0.06f).toInt()
        content.setPadding(pad, pad, pad, pad)
        artHolder.setPadding(0, 0, pad, 0)

        val small = (base * 0.16f).toInt()
        val big = (base * 0.21f).toInt()
        val gap = (base * 0.03f).toInt()
        sizeButton(btnPrev, small, gap)
        sizeButton(btnPlay, big, gap)
        sizeButton(btnNext, small, gap)

        val menu = (base * 0.10f).toInt()
        btnMenu.layoutParams = btnMenu.layoutParams.apply {
            width = menu
            height = menu
        }
        val edge = (base * 0.02f).toInt()
        tvStatus.setPadding(edge, edge, pad, edge)
    }

    private fun sizeButton(b: ImageButton, size: Int, margin: Int) {
        val lp = LinearLayout.LayoutParams(size, size)
        lp.leftMargin = margin
        lp.rightMargin = margin
        b.layoutParams = lp
        val p = (size * 0.22f).toInt()
        b.setPadding(p, p, p, p)
    }

    // ---------------------------------------------------------------- dibujo

    private fun render() {
        val t = PlayerModel.current()
        val enabled = isListenerEnabled()

        val title: String
        val artist: String
        val album: String
        val placeholder: Boolean
        if (t != null) {
            title = t.title
            artist = t.artist
            album = t.album
            placeholder = false
        } else if (!enabled) {
            title = "Falta el acceso a notificaciones"
            artist = "Toca ⋮ y elige «Acceso a notificaciones»"
            album = ""
            placeholder = true
        } else {
            title = "Esperando reproducción"
            artist = ""
            album = ""
            placeholder = true
        }

        if (title != shownTitle || placeholder != titleIsPlaceholder) {
            tvTitle.text = title
            tvTitle.setTextColor(if (placeholder) Color.parseColor("#7E8088") else Color.WHITE)
            shownTitle = title
            titleIsPlaceholder = placeholder
        }
        if (artist != shownArtist) {
            tvArtist.text = artist
            shownArtist = artist
        }
        if (album != shownAlbum) {
            tvAlbum.text = album
            shownAlbum = album
        }

        val art = PlayerModel.currentArt()
        if (art !== shownArt) {
            shownArt = art
            if (art != null) ivArt.setImageBitmap(art) else ivArt.setImageDrawable(null)
        }

        val playing = t?.playing == true
        if (shownPlaying != playing) {
            shownPlaying = playing
            btnPlay.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
        }

        val status: String
        val color: String
        if (PlayerModel.linkConnected) {
            status = "● Teléfono conectado"
            color = "#4CAF50"
        } else if (PlayerModel.avrcpSession != null) {
            status = "● Bluetooth · sin carátulas"
            color = "#FFB300"
        } else {
            status = "● Sin conexión"
            color = "#6B6E75"
        }
        if (status != shownStatus) {
            shownStatus = status
            tvStatus.text = status
            tvStatus.setTextColor(Color.parseColor(color))
        }

        updateProgress()
    }

    private fun updateProgress() {
        val t = PlayerModel.current()
        if (t == null) {
            progress.progress = 0
            tvPos.text = "--:--"
            tvDur.text = "--:--"
            return
        }
        val pos = t.positionNow()
        tvPos.text = formatTime(pos)
        if (t.durationMs > 0L) {
            tvDur.text = formatTime(t.durationMs)
            progress.progress = ((pos * 1000L) / t.durationMs).toInt().coerceIn(0, 1000)
        } else {
            tvDur.text = "--:--"
            progress.progress = 0
        }
    }

    private fun formatTime(ms: Long): String {
        val total = ms / 1000L
        return String.format("%d:%02d", total / 60L, total % 60L)
    }

    // ---------------------------------------------------------------- ajustes y diagnóstico

    private fun showSettings() {
        val labels = arrayOf(
            "Pantalla completa",
            "Mantener la pantalla encendida",
            "Iniciar al arrancar la unidad",
            "Compatibilidad: enlace sin cifrar (solo si el teléfono no conecta)"
        )
        val checked = booleanArrayOf(prefs.fullscreen, prefs.keepOn, prefs.autostart, prefs.insecureLink)
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.app_name))
            .setMultiChoiceItems(labels, checked) { _, which, isChecked ->
                when (which) {
                    0 -> {
                        prefs.fullscreen = isChecked
                        applyWindow()
                    }
                    1 -> {
                        prefs.keepOn = isChecked
                        applyWindow()
                    }
                    2 -> {
                        prefs.autostart = isChecked
                        if (isChecked) ensureOverlayPermission()
                    }
                    3 -> {
                        prefs.insecureLink = isChecked
                        PlayerModel.linkServer?.reopen()
                    }
                }
            }
            .setPositiveButton("Cerrar", null)
            .setNegativeButton("Diagnóstico") { _, _ -> showDiagnostics() }
            .setNeutralButton("Acceso a notificaciones") { _, _ -> openNotificationAccess() }
            .show()
    }

    private fun ensureOverlayPermission() {
        if (Settings.canDrawOverlays(this)) return
        try {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            Toast.makeText(
                this,
                "Concede «Mostrar sobre otras apps» para que CarMusic pueda abrirse al arrancar",
                Toast.LENGTH_LONG
            ).show()
        } catch (e: Exception) {
            Log.e(TAG, "No se pudo abrir el permiso de superposición", e)
            Toast.makeText(this, "Esta unidad no ofrece ese permiso; el inicio automático puede no funcionar", Toast.LENGTH_LONG).show()
        }
    }

    private fun openNotificationAccess() {
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } catch (e: Exception) {
            Log.e(TAG, "No se pudo abrir el acceso a notificaciones", e)
            Toast.makeText(this, "No se pudo abrir los ajustes de acceso a notificaciones", Toast.LENGTH_LONG).show()
        }
    }

    private fun showDiagnostics() {
        val text = buildDiagnostics()
        AlertDialog.Builder(this)
            .setTitle("Diagnóstico")
            .setMessage(text)
            .setPositiveButton("Cerrar", null)
            .setNegativeButton("Copiar") { _, _ ->
                try {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("CarMusic diagnóstico", text))
                    Toast.makeText(this, "Diagnóstico copiado", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Log.e(TAG, "No se pudo copiar el diagnóstico", e)
                }
            }
            .show()
    }

    private fun buildDiagnostics(): String {
        val sb = StringBuilder()
        val adapter: BluetoothAdapter? = try {
            BluetoothAdapter.getDefaultAdapter()
        } catch (e: Exception) {
            null
        }
        val version = try {
            packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: Exception) {
            "?"
        }
        sb.appendLine("CarMusic $version · ${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        sb.appendLine()
        sb.appendLine("Acceso a notificaciones: " + if (isListenerEnabled()) "concedido" else "NO concedido")
        sb.appendLine("Servicio enlazado: " + if (PlayerModel.serviceConnected) "sí" else "no")
        sb.appendLine()
        sb.appendLine("── Capacidades Bluetooth de la unidad ──")
        if (adapter == null) {
            sb.appendLine("Adaptador Bluetooth: NO presente")
        } else {
            sb.appendLine("Adaptador Bluetooth: presente, " + if (adapter.isEnabled) "encendido" else "APAGADO")
            sb.appendLine(
                "BLE (Bluetooth Low Energy): " +
                    if (packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) "soportado" else "NO soportado"
            )
            sb.appendLine(
                "BLE modo periférico (publicidad): " +
                    if (adapter.isMultipleAdvertisementSupported) "soportado" else "NO soportado"
            )
        }
        sb.appendLine(
            "Servidor RFCOMM: " + if (PlayerModel.linkListening) "ESCUCHANDO (UUID ${Protocol.SERVICE_UUID})"
            else "NO activo — ${PlayerModel.linkError ?: "sin detalle"}"
        )
        sb.appendLine("Modo del enlace: " + if (prefs.insecureLink) "sin cifrar (compatibilidad)" else "seguro (solo dispositivos emparejados)")
        sb.appendLine()
        sb.appendLine("── Enlace con el teléfono ──")
        if (PlayerModel.linkConnected) {
            sb.appendLine("Conectado a: ${PlayerModel.linkDevice ?: "?"}")
            sb.appendLine(
                "Carátula recibida: " +
                    if (PlayerModel.linkArt != null) "sí (${PlayerModel.linkArtBytes / 1024} KB)" else "todavía no"
            )
        } else {
            sb.appendLine("Sin teléfono conectado (abre CarMusic Companion en el teléfono)")
        }
        sb.appendLine()
        sb.appendLine("── Sesión AVRCP (Bluetooth del sistema) ──")
        val pkg = PlayerModel.avrcpSession
        if (pkg == null) {
            sb.appendLine("Sin sesión")
        } else {
            sb.appendLine("Paquete: $pkg")
            val a = PlayerModel.avrcp
            if (a == null) {
                sb.appendLine("Sin canción publicada")
            } else {
                sb.appendLine("Título: ${a.title}")
                sb.appendLine("Artista: ${a.artist}")
                sb.appendLine("Álbum: ${a.album}")
                sb.appendLine("Duración: ${formatTime(a.durationMs)}")
                sb.appendLine("Estado: " + if (a.playing) "reproduciendo" else "pausado")
            }
            sb.appendLine("Carátula por AVRCP: " + if (PlayerModel.avrcpArt != null) "sí" else "no")
        }
        sb.appendLine()
        sb.appendLine("Fuente mostrada: " + (PlayerModel.current()?.source ?: "ninguna"))
        return sb.toString()
    }

    private fun isListenerEnabled(): Boolean = try {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        val me = ComponentName(this, CarService::class.java)
        flat?.split(":")?.any { ComponentName.unflattenFromString(it) == me } == true
    } catch (e: Exception) {
        Log.e(TAG, "Error comprobando el acceso a notificaciones", e)
        false
    }

    private companion object {
        const val TAG = "CarMusic"
    }
}
