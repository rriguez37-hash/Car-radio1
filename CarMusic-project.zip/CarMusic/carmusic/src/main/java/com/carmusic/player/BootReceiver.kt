package com.carmusic.player

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * Abre CarMusic al arrancar la unidad si el usuario lo activó en los ajustes.
 * En Android 10+ puede requerir el permiso "Mostrar sobre otras apps" (ver README).
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (!Prefs(context).autostart) return
        try {
            val launch = Intent(context, MainActivity::class.java)
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launch)
            Log.i(TAG, "Inicio automático solicitado (${intent.action})")
        } catch (e: Exception) {
            Log.e(TAG, "No se pudo iniciar CarMusic al arrancar", e)
        }
    }

    private companion object {
        const val TAG = "CarMusic"
    }
}
