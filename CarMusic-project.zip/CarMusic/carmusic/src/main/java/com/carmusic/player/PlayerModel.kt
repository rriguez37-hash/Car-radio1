package com.carmusic.player

import android.graphics.Bitmap
import android.media.session.MediaController
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import com.carmusic.shared.Meta
import com.carmusic.shared.Protocol
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Estado único de la reproducción en la pantalla. Se modifica SIEMPRE en el hilo principal
 * (los hilos de Bluetooth usan [post]) y la interfaz lo observa con [Listener].
 *
 * Dos fuentes:
 *  - AVRCP: la sesión multimedia `com.android.bluetooth` del propio Android de la unidad.
 *           Da título, artista, álbum, duración, posición y controles, pero NO carátula.
 *  - Enlace: el teléfono (Companion) por RFCOMM. Añade carátula y, si está conectado, manda sobre AVRCP.
 */
object PlayerModel {
    private const val TAG = "CarMusic"

    interface Listener {
        fun onModelChanged()
    }

    class Track(
        val title: String,
        val artist: String,
        val album: String,
        val durationMs: Long,
        val positionMs: Long,
        /** Valor de SystemClock.elapsedRealtime() al que corresponde [positionMs]. */
        val positionTimeMs: Long,
        val speed: Float,
        val playing: Boolean,
        val source: String
    ) {
        fun positionNow(): Long {
            var p = positionMs
            if (playing) p += ((SystemClock.elapsedRealtime() - positionTimeMs) * speed).toLong()
            if (p < 0L) p = 0L
            if (durationMs > 0L && p > durationMs) p = durationMs
            return p
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<Listener>()

    // ---- Servicio
    var serviceConnected: Boolean = false

    // ---- Fuente AVRCP
    var avrcpSession: String? = null
    var avrcp: Track? = null
    var avrcpArt: Bitmap? = null
    var avrcpController: MediaController? = null

    // ---- Fuente enlace RFCOMM (teléfono)
    var linkListening: Boolean = false
    var linkError: String? = null
    var linkConnected: Boolean = false
    var linkDevice: String? = null
    var link: Track? = null
    var linkKey: Int = 0
    var linkArt: Bitmap? = null
    var linkArtKey: Int = 0
    var linkArtBytes: Int = 0
    var linkServer: LinkServer? = null

    fun post(block: () -> Unit) {
        main.post { block() }
    }

    fun addListener(l: Listener) {
        listeners.addIfAbsent(l)
    }

    fun removeListener(l: Listener) {
        listeners.remove(l)
    }

    fun notifyChanged() {
        for (l in listeners) l.onModelChanged()
    }

    /** Canción que se muestra: la del teléfono si el enlace está activo y tiene sesión; si no, AVRCP. */
    fun current(): Track? {
        val l = link
        return if (linkConnected && l != null) l else avrcp
    }

    fun currentSourceIsLink(): Boolean = linkConnected && link != null

    fun currentArt(): Bitmap? {
        if (currentSourceIsLink()) return if (linkArtKey == linkKey) linkArt else null
        return avrcpArt
    }

    // ---------------------------------------------------------------- AVRCP

    fun setAvrcp(sessionPackage: String?, track: Track?, art: Bitmap?) {
        avrcpSession = sessionPackage
        avrcp = track
        avrcpArt = art
        notifyChanged()
    }

    // ---------------------------------------------------------------- enlace

    fun setListening(listening: Boolean, error: String?) {
        linkListening = listening
        linkError = error
        notifyChanged()
    }

    fun setLinkConnected(connected: Boolean, device: String?) {
        linkConnected = connected
        linkDevice = if (connected) device else null
        if (!connected) {
            link = null
            linkArt = null
            linkArtBytes = 0
        }
        notifyChanged()
    }

    fun setLinkMeta(m: Meta) {
        link = if (m.hasSession) {
            Track(
                m.title, m.artist, m.album, m.durationMs, m.positionMs,
                SystemClock.elapsedRealtime(), 1f, m.playing, "Teléfono (${m.sourcePackage})"
            )
        } else {
            null
        }
        linkKey = m.trackKey
        notifyChanged()
    }

    fun setLinkArt(key: Int, bitmap: Bitmap?, bytes: Int) {
        linkArt = bitmap
        linkArtKey = key
        linkArtBytes = bytes
        notifyChanged()
    }

    // ---------------------------------------------------------------- controles

    /**
     * Envía una orden. Si el enlace con el teléfono está activo se manda por ahí (el teléfono pulsa
     * los controles de YouTube Music directamente); si no, por los controles AVRCP de la sesión Bluetooth.
     */
    fun sendCommand(cmd: Int): Boolean {
        val server = linkServer
        if (linkConnected && server != null && server.sendCommand(cmd)) return true
        val c = avrcpController ?: return false
        return try {
            val tc = c.transportControls
            when (cmd) {
                Protocol.CMD_PLAY -> tc.play()
                Protocol.CMD_PAUSE -> tc.pause()
                Protocol.CMD_NEXT -> tc.skipToNext()
                Protocol.CMD_PREV -> tc.skipToPrevious()
                Protocol.CMD_TOGGLE -> if (avrcp?.playing == true) tc.pause() else tc.play()
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error enviando orden AVRCP $cmd", e)
            false
        }
    }
}
