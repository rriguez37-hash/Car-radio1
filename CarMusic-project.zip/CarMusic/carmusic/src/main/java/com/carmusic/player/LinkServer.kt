package com.carmusic.player

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.util.Log
import com.carmusic.shared.FrameIO
import com.carmusic.shared.Meta
import com.carmusic.shared.Protocol
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.Closeable
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Servidor Bluetooth RFCOMM de la pantalla. Publica el servicio [Protocol.SERVICE_UUID] y acepta al
 * teléfono (Companion). Solo hay un teléfono activo: una conexión nueva sustituye a la anterior.
 *
 * Todas las llamadas de [Callbacks] llegan desde hilos de Bluetooth, no del principal.
 */
class LinkServer(
    private val callbacks: Callbacks,
    /** true = el servidor acepta también enlaces sin cifrar (modo compatibilidad, ver ajustes). */
    private val insecure: () -> Boolean
) {

    interface Callbacks {
        fun onListening(listening: Boolean, error: String?)
        fun onConnected(deviceName: String?)
        fun onDisconnected()
        fun onMeta(meta: Meta)
        fun onArt(key: Int, jpeg: ByteArray)
    }

    @Volatile private var running = false
    @Volatile private var server: BluetoothServerSocket? = null
    @Volatile private var client: BluetoothSocket? = null
    @Volatile private var out: DataOutputStream? = null
    private var acceptThread: Thread? = null
    private var writer: ExecutorService? = null

    fun start() {
        if (running) return
        running = true
        writer = Executors.newSingleThreadExecutor()
        val t = Thread({ acceptLoop() }, "carmusic-accept")
        t.isDaemon = true
        acceptThread = t
        t.start()
    }

    fun stop() {
        running = false
        closeQuietly(server)
        closeQuietly(client)
        acceptThread?.interrupt()
        writer?.shutdownNow()
        writer = null
    }

    /** Cierra el servidor para que se vuelva a abrir leyendo otra vez el modo (seguro / sin cifrar). */
    fun reopen() {
        closeQuietly(server)
    }

    /** Envía una orden al teléfono. Devuelve false si no hay enlace. */
    fun sendCommand(cmd: Int): Boolean {
        val o = out ?: return false
        val w = writer ?: return false
        try {
            w.execute {
                try {
                    FrameIO.write(o, Protocol.T_CMD, byteArrayOf(cmd.toByte()))
                } catch (e: IOException) {
                    Log.w(TAG, "Error enviando orden $cmd: ${e.message}")
                    closeQuietly(client)
                }
            }
        } catch (e: Exception) {
            return false
        }
        return true
    }

    // ---------------------------------------------------------------- aceptar conexiones

    private fun acceptLoop() {
        var backoff = 2_000L
        while (running) {
            val adapter: BluetoothAdapter? = try {
                BluetoothAdapter.getDefaultAdapter()
            } catch (e: Exception) {
                null
            }
            if (adapter == null) {
                callbacks.onListening(false, "Esta unidad no tiene adaptador Bluetooth")
                pause(10_000L)
                continue
            }
            if (!adapter.isEnabled) {
                callbacks.onListening(false, "Bluetooth apagado")
                pause(5_000L)
                continue
            }

            var ss: BluetoothServerSocket? = null
            try {
                val created: BluetoothServerSocket = if (insecure()) {
                    adapter.listenUsingInsecureRfcommWithServiceRecord(Protocol.SERVICE_NAME, Protocol.SERVICE_UUID)
                } else {
                    adapter.listenUsingRfcommWithServiceRecord(Protocol.SERVICE_NAME, Protocol.SERVICE_UUID)
                }
                ss = created
                server = created
                callbacks.onListening(true, null)
                Log.i(TAG, "Servidor RFCOMM escuchando")
                backoff = 2_000L
                while (running) {
                    val sock = created.accept() // bloquea hasta que el teléfono conecte
                    startClient(sock)
                }
            } catch (e: IOException) {
                if (running) {
                    Log.w(TAG, "Servidor RFCOMM: ${e.message}")
                    callbacks.onListening(false, e.message ?: "Error de entrada/salida")
                }
            } catch (e: SecurityException) {
                Log.e(TAG, "Sin permiso Bluetooth", e)
                callbacks.onListening(false, "Sin permiso Bluetooth: ${e.message}")
            } catch (e: Exception) {
                Log.e(TAG, "Error inesperado en el servidor RFCOMM", e)
                callbacks.onListening(false, "${e.javaClass.simpleName}: ${e.message}")
            } finally {
                closeQuietly(ss)
                server = null
            }
            if (running) {
                pause(backoff)
                backoff = minOf(backoff * 2, 30_000L)
            }
        }
    }

    private fun startClient(sock: BluetoothSocket) {
        // Una conexión nueva sustituye a la anterior (evita enlaces "fantasma" a medio cerrar).
        closeQuietly(client)
        client = sock
        val t = Thread({ clientLoop(sock) }, "carmusic-client")
        t.isDaemon = true
        t.start()
    }

    private fun clientLoop(sock: BluetoothSocket) {
        val name: String? = try {
            sock.remoteDevice?.name
        } catch (e: SecurityException) {
            null
        }
        try {
            val input = DataInputStream(BufferedInputStream(sock.inputStream))
            val output = DataOutputStream(BufferedOutputStream(sock.outputStream))
            out = output
            Log.i(TAG, "Teléfono conectado: $name")
            callbacks.onConnected(name)
            while (running) {
                val f = FrameIO.read(input)
                when (f.type) {
                    Protocol.T_META -> callbacks.onMeta(Meta.decode(f.payload))
                    Protocol.T_ART -> callbacks.onArt(
                        Protocol.decodeArtKey(f.payload),
                        Protocol.decodeArtBytes(f.payload)
                    )
                    else -> Unit // HELLO y tipos desconocidos: se ignoran
                }
            }
        } catch (e: IOException) {
            Log.i(TAG, "Enlace cerrado: ${e.message}")
        } catch (e: Exception) {
            Log.e(TAG, "Error en el enlace con el teléfono", e)
        } finally {
            if (client === sock) {
                client = null
                out = null
                callbacks.onDisconnected()
            }
            closeQuietly(sock)
        }
    }

    private fun pause(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (e: InterruptedException) {
            // stop() interrumpe la espera
        }
    }

    private fun closeQuietly(c: Closeable?) {
        try {
            c?.close()
        } catch (e: Exception) {
            // nada que hacer
        }
    }

    private companion object {
        const val TAG = "CarMusic"
    }
}
