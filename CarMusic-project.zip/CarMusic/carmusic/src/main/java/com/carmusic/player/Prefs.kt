package com.carmusic.player

import android.content.Context
import android.content.SharedPreferences

/** Preferencias persistentes de CarMusic. */
class Prefs(context: Context) {

    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("carmusic", Context.MODE_PRIVATE)

    /** Barras del sistema ocultas (modo inmersivo). */
    var fullscreen: Boolean
        get() = sp.getBoolean("fullscreen", true)
        set(value) { sp.edit().putBoolean("fullscreen", value).apply() }

    /** Evitar que la pantalla se apague mientras CarMusic está abierta. */
    var keepOn: Boolean
        get() = sp.getBoolean("keep_on", true)
        set(value) { sp.edit().putBoolean("keep_on", value).apply() }

    /** Modo compatibilidad: el servidor RFCOMM acepta también enlaces sin cifrar. Solo si el seguro no conecta. */
    var insecureLink: Boolean
        get() = sp.getBoolean("insecure_link", false)
        set(value) { sp.edit().putBoolean("insecure_link", value).apply() }

    /** Abrir CarMusic al arrancar la unidad. */
    var autostart: Boolean
        get() = sp.getBoolean("autostart", false)
        set(value) { sp.edit().putBoolean("autostart", value).apply() }
}
