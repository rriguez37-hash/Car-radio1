import com.android.build.gradle.internal.api.BaseVariantOutputImpl

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.carmusic.player"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.carmusic.player"
        minSdk = 23
        // Android 11 = API 30
        targetSdk = 30
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = false
            // Firma con la clave debug para poder instalar el APK release sin keystore propio.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    // El APK siempre se llama CarMusic.apk
    applicationVariants.all {
        outputs.all {
            (this as BaseVariantOutputImpl).outputFileName = "CarMusic.apk"
        }
    }

    // Protocolo compartido con la app del teléfono
    sourceSets.getByName("main").java.srcDir("../shared/src/main/kotlin")

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

// Sin dependencias externas: solo el framework Android y la librería estándar de Kotlin.
dependencies {
}
