# CarMusic

Reproductor visual para la pantalla Android del coche (ZXDZ_01, Android 11.1) que muestra lo que suena en el teléfono por Bluetooth. Son **dos apps independientes** en un solo proyecto:

| App | APK | Dónde se instala | Qué hace |
|---|---|---|---|
| **CarMusic** | `CarMusic.apk` | Pantalla del coche | Interfaz del reproductor, servidor Bluetooth RFCOMM, lee la sesión AVRCP del sistema, controles |
| **CarMusic Companion** | `CarMusic-Companion.apk` | Teléfono | Lee YouTube Music, obtiene la carátula original y la envía a la pantalla; ejecuta las órdenes de la pantalla |

El audio sigue yendo por el A2DP normal del coche. Estas apps solo muestran metadatos y controlan la reproducción.

> **Estado: el código no se ha compilado ni probado en un dispositivo.** Se revisó a mano (recursos, manifiestos, Gradle) pero el primer build real y la primera prueba en la unidad pueden destapar errores. Nada de lo descrito aquí como «funciona» está verificado en tu pantalla salvo lo que indica la sección «Lo que ya se sabe de tu unidad».

## Lo que ya se sabe de tu unidad (diagnóstico real)

Con CarMusic Diagnostic instalado en la pantalla se obtuvo:

- Solo existe una sesión multimedia: `com.android.bluetooth` (el AVRCP del Android de la unidad).
- Esa sesión entrega **título, artista, álbum, duración, posición y estado**.
- **No entrega carátula** (ni Bitmap ni URI, en ninguna clave).
- Por tanto la pantalla recibe texto por AVRCP pero no imágenes: no es un fallo de YouTube Music, es lo que el enlace AVRCP de esa unidad transporta. Una app normal no puede cambiarlo.

De ahí el diseño:

1. **Sin Companion**: CarMusic ya funciona con lo que da AVRCP (texto, progreso y controles anterior/pausa/siguiente mediante los controles de esa sesión). Sin carátula.
2. **Con Companion**: el teléfono envía además la carátula por un canal propio y los controles pasan por ahí. Es la única vía para tener carátula en esta unidad.

(El indicador «Bluetooth: desconectado» de CarMusic Diagnostic era un falso negativo: miraba salidas A2DP y la pantalla es receptora. CarMusic no usa ese dato.)

## Comunicación Bluetooth: BLE GATT frente a RFCOMM

| Opción | Estado |
|---|---|
| **RFCOMM (Bluetooth clásico)** | **Implementada.** Flujo de bytes fiable; la pantalla publica un servicio con UUID propio y el teléfono se conecta a ella. Encaja con enviar una imagen JPEG (30-70 KB) sin paquetes de 20 bytes. |
| BLE GATT | **No implementada como transporte.** Exigiría que la unidad actúe como periférico BLE (publicidad) y MTU pequeñas para la imagen. El diagnóstico de CarMusic indica si la unidad soporta BLE y modo periférico, por si hiciera falta como plan B. |

Si el servidor RFCOMM no consigue abrirse en la unidad (el diagnóstico lo dirá), la alternativa viable sin cables es **Wi-Fi local**: el teléfono comparte su punto de acceso, la pantalla se conecta y el Companion envía los mismos datos por un socket TCP. No está implementado; se haría reutilizando el mismo protocolo (`shared/Protocol.kt`).

El protocolo (`shared/src/main/kotlin/com/carmusic/shared/Protocol.kt`) usa tramas `[tipo][longitud][contenido]`. La carátula se reduce a 512 px y se comprime a JPEG (calidad 80); se escribe en fragmentos de 4 KB. RFCOMM ya es un flujo ordenado y fiable, así que no hace falta más fragmentación.

## Estructura

```
CarMusic/
├─ settings.gradle.kts · build.gradle.kts · gradle.properties · gradlew
├─ shared/src/main/kotlin/…/Protocol.kt      Protocolo común (lo compilan las dos apps)
├─ carmusic/                                  App de la pantalla (CarMusic.apk)
│  └─ src/main/java/com/carmusic/player/
│     ├─ MainActivity.kt      Interfaz, ajustes, diagnóstico
│     ├─ CarService.kt        NotificationListenerService: sesión AVRCP + servidor RFCOMM
│     ├─ LinkServer.kt        Servidor RFCOMM
│     ├─ PlayerModel.kt       Estado único de reproducción
│     ├─ RoundedSquareImageView.kt · Prefs.kt · BootReceiver.kt
└─ companion/                                 App del teléfono (CarMusic-Companion.apk)
   └─ src/main/java/com/carmusic/companion/
      ├─ CompanionService.kt  NotificationListenerService: sesiones, carátula, órdenes
      ├─ LinkClient.kt        Cliente RFCOMM con reconexión
      ├─ ArtResolver.kt       Búsqueda y compresión de la carátula
      ├─ MainActivity.kt · CompanionState.kt · Prefs.kt
```

## Permisos

**CarMusic (pantalla)**

| Permiso | Para qué |
|---|---|
| `BLUETOOTH` | Servidor RFCOMM y consulta del adaptador |
| `RECEIVE_BOOT_COMPLETED` | Abrir CarMusic al arrancar (opción desactivada por defecto) |
| `SYSTEM_ALERT_WINDOW` | Solo si activas «Iniciar al arrancar»: Android 10+ exige «Mostrar sobre otras apps» para abrir una app al arrancar |
| Acceso a notificaciones (lo concedes tú) | Android solo deja leer las sesiones multimedia a una app con un `NotificationListenerService` habilitado. No lee ni guarda notificaciones |

Sin `INTERNET`.

**CarMusic Companion (teléfono)**

| Permiso | Para qué |
|---|---|
| `BLUETOOTH`, `BLUETOOTH_CONNECT` | Listar dispositivos emparejados y abrir el canal RFCOMM |
| `INTERNET` | Solo para descargar la carátula cuando YouTube Music la publica como URL `https`. No se envía nada a ningún servidor |
| Acceso a notificaciones (lo concedes tú) | Leer las sesiones multimedia y el icono grande de la notificación de reproducción (alternativa de carátula) |

No se usan APIs privadas, credenciales de Google, scraping ni permisos de sistema.

## Carátula: de dónde sale

El Companion prueba, por orden, hasta conseguir una (y vuelve a intentarlo si aparece una mejor):

1. Bitmap dentro de la `MediaMetadata` (`ALBUM_ART`, `ART`, `DISPLAY_ICON`) o URI local legible.
2. URI `https` publicada por YouTube Music (se descarga).
3. Icono grande de la notificación de reproducción.

La pantalla del Companion muestra cuál de las tres funcionó («Carátula: …»). Si ninguna da imagen, se mostrará «sin carátula» y esa limitación quedará registrada en el diagnóstico.

## Compilar con GitHub (desde el móvil)

Es el método que ya usaste con el diagnóstico.

1. En tu repositorio: **Add file > Upload files** y sube `CarMusic-project.zip` **sin descomprimir**. (Puedes dejar el ZIP anterior.)
2. Abre `.github/workflows/build.yml`, toca el lápiz, borra todo y pega:

```yaml
name: Build APK

on:
  workflow_dispatch:
  push:
    branches: [ main, master ]

jobs:
  build:
    runs-on: ubuntu-24.04
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-java@v5
        with:
          distribution: temurin
          java-version: 17

      - name: Descomprimir proyecto
        run: unzip -q -o CarMusic-project.zip

      - name: Compilar los dos APK
        working-directory: CarMusic
        run: |
          chmod +x ./gradlew
          ./gradlew assembleDebug --stacktrace

      - uses: actions/upload-artifact@v4
        with:
          name: CarMusic
          path: CarMusic/carmusic/build/outputs/apk/debug/CarMusic.apk

      - uses: actions/upload-artifact@v4
        with:
          name: CarMusic-Companion
          path: CarMusic/companion/build/outputs/apk/debug/CarMusic-Companion.apk
```

3. **Commit changes**. En **Actions** se lanza **Build APK** (varios minutos).
4. Con el check verde, baja al final de la ejecución, a **Artifacts**, y descarga `CarMusic` y `CarMusic-Companion` (cada uno es un ZIP con su APK).

Con Android Studio: abrir la carpeta `CarMusic`, esperar al sync y `./gradlew assembleDebug`. Los APK quedan en `carmusic/build/outputs/apk/debug/CarMusic.apk` y `companion/build/outputs/apk/debug/CarMusic-Companion.apk`.

## Instalación y configuración

**En la pantalla del coche (CarMusic.apk)**

1. Instala el APK y ábrelo. Aparece «Falta el acceso a notificaciones».
2. Toca **⋮** (arriba a la izquierda) > **Acceso a notificaciones** y activa **CarMusic**. (El acceso concedido a CarMusic Diagnostic no sirve: es otra app.)
3. Reproduce música en el teléfono conectado por Bluetooth: ya verás título, artista, álbum, progreso y los botones. Sin carátula todavía.

**En el teléfono (CarMusic-Companion.apk)**

1. Instala el APK y ábrelo. Si Android pide el permiso de dispositivos cercanos, acéptalo.
2. **Acceso a notificaciones** > activa **CarMusic Companion**. En Android 13+ con el interruptor gris: Ajustes > Aplicaciones > CarMusic Companion > menú ⋮ > «Permitir ajustes restringidos», y repite.
3. **Elegir pantalla del coche**: selecciona la pantalla entre los dispositivos emparejados (la que ya usas para el audio).
4. Reproduce música en YouTube Music. El enlace debe pasar a «Conectado» y la pantalla mostrará «● Teléfono conectado» y la carátula.

**Si el enlace no conecta**

- En la pantalla toca el indicador de arriba a la derecha (o ⋮ > Diagnóstico): dirá si el servidor RFCOMM está escuchando y si la unidad soporta BLE.
- En el Companion, **Copiar diagnóstico** y pégalo para revisarlo.
- Prueba en la pantalla ⋮ > «Compatibilidad: enlace sin cifrar». El teléfono ya prueba solo los dos modos.

## Pruebas recomendadas (en este orden)

1. **Solo CarMusic**: ¿aparecen título, artista, álbum y avanza el progreso? ¿Funcionan anterior / pausa / siguiente?
2. **Diagnóstico de la pantalla**: ¿«Servidor RFCOMM: ESCUCHANDO»?
3. **Companion**: ¿pasa a «Conectado»? ¿qué fuente de carátula informa?
4. **Carátula en la pantalla** al cambiar de canción.
5. **Controles con el Companion conectado** (pasan por el teléfono).
6. **Reconexión**: apaga y enciende el Bluetooth del teléfono; debe reconectar solo.

## Otras opciones de la pantalla (⋮)

- Pantalla completa (barras ocultas; algunas unidades tienen una barra fija que no se puede ocultar).
- Mantener la pantalla encendida.
- Iniciar al arrancar la unidad: depende de la ROM; si no abre sola, concede «Mostrar sobre otras apps» a CarMusic.

## Limitaciones conocidas

1. **Carátula por AVRCP**: no existe en esta unidad (ver arriba). Solo llega con el Companion.
2. **Android no ofrece API pública para forzar la carátula** al coche por el Bluetooth del sistema.
3. **Fiabilidad de RFCOMM** con el stack Bluetooth de la unidad: sin probar. Plan B: Wi-Fi local.
4. **Servicios en segundo plano**: ambos servicios los mantiene vivos el sistema mientras el acceso a notificaciones esté concedido. Algunos fabricantes de móviles los matan; excluye el Companion del ahorro de batería si pasa.
5. **Autoarranque** de CarMusic: depende de la ROM de la unidad.
6. `targetSdk 30` intencional (Android 11); válido para instalación directa, no para Google Play.
7. Rendimiento y diseño probados solo sobre el papel: los tamaños se calculan proporcionales a la pantalla, pero no se han visto en tu unidad.
