package com.carmusic.companion

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Estado visible en la pantalla del Companion y registro corto para copiar como diagnóstico. */
object CompanionState {
    @Volatile var serviceConnected: Boolean = false
    @Volatile var linkConnected: Boolean = false
    @Volatile var linkStatus: String = "Sin iniciar"
    @Volatile var sessionPackage: String = ""
    @Volatile var title: String = ""
    @Volatile var artist: String = ""
    @Volatile var album: String = ""
    @Volatile var playing: Boolean = false
    @Volatile var artInfo: String = "sin carátula"
    @Volatile var lastCommand: String = "ninguna"

    private val lines = ArrayList<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    private var lastRaw: String = ""

    /** Añade una línea al registro; las repetidas seguidas se ignoran (los reintentos no lo inundan). */
    @Synchronized
    fun log(line: String) {
        if (line == lastRaw) return
        lastRaw = line
        lines.add(fmt.format(Date()) + "  " + line)
        while (lines.size > 60) lines.removeAt(0)
    }

    @Synchronized
    fun logText(): String = lines.joinToString("\n")
}
