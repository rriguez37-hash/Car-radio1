package com.carmusic.companion

import android.app.Notification
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.Icon
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.carmusic.shared.Meta
import com.carmusic.shared.Protocol
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Servicio del teléfono. Es un NotificationListenerService porque Android solo permite a una app normal
 * leer las sesiones multimedia si tiene uno habilitado. Aquí vive todo:
 *  - observa la sesión de YouTube Music (o, si no existe, la que esté reproduciendo),
 *  - obtiene la carátula original,
 *  - la envía a la pantalla por Bluetooth RFCOMM y ejecuta las órdenes que lleguen de la pantalla.
 *
 * No lee notificaciones salvo el icono grande de la notificación multimedia, como alternativa de carátula.
 */
class CompanionService : NotificationListenerService() {

    private class ArtState(val key: Int, val rank: Int, val jpeg: ByteArray, val source: String)

    private val main = Handler(Looper.getMainLooper())
    private val worker: ExecutorService = Executors.newSingleThreadExecutor()

    private var msm: MediaSessionManager? = null
    private var me: ComponentName? = null
    private var controller: MediaController? = null
    private var token: MediaSession.Token? = null
    private var link: LinkClient? = null
    private var sessionsRegistered = false
    private var aclRegistered = false

    private var lastSent: Meta? = null
    private var lastSentAt = 0L
    private var art: ArtState? = null
    private val notifIcons = HashMap<String, Bitmap>()
    private var lastScheduleSig = ""
    private var lastScheduleAt = 0L

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) {
            pushMeta(false)
            scheduleArt()
        }

        override fun onPlaybackStateChanged(state: PlaybackState?) {
            pushMeta(false)
        }

        override fun onSessionDestroyed() {
            pickSession()
        }
    }

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { pickSession() }

    private val linkCallbacks = object : LinkClient.Callbacks {
        override fun onStatus(text: String) {
            CompanionState.linkStatus = text
            CompanionState.log(text)
        }

        override fun onConnected() {
            CompanionState.linkConnected = true
            main.post { sendEverything() }
        }

        override fun onDisconnected() {
            CompanionState.linkConnected = false
            CompanionState.log("Enlace cerrado")
        }

        override fun onCommand(cmd: Int) {
            main.post { handleCommand(cmd) }
        }
    }

    /** Cuando el teléfono se conecta (audio) a la pantalla, se intenta el enlace de inmediato. */
    private val aclReceiver = object : BroadcastReceiver() {
        @Suppress("DEPRECATION")
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != BluetoothDevice.ACTION_ACL_CONNECTED) return
            val dev: BluetoothDevice? = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
            if (dev != null && dev.address == Prefs(context).carAddress) link?.nudge()
        }
    }

    // ---------------------------------------------------------------- ciclo de vida

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        CompanionState.serviceConnected = true
        CompanionState.log("Servicio conectado")
        msm = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        me = ComponentName(this, CompanionService::class.java)

        val m = msm
        val c = me
        if (m != null && c != null && !sessionsRegistered) {
            try {
                m.addOnActiveSessionsChangedListener(sessionsListener, c, main)
                sessionsRegistered = true
            } catch (e: Exception) {
                Log.e(TAG, "No se pudo escuchar las sesiones multimedia", e)
                CompanionState.log("Error escuchando sesiones: ${e.javaClass.simpleName}")
            }
        }
        if (!aclRegistered) {
            try {
                registerReceiver(aclReceiver, IntentFilter(BluetoothDevice.ACTION_ACL_CONNECTED))
                aclRegistered = true
            } catch (e: Exception) {
                Log.e(TAG, "No se pudo registrar el receptor Bluetooth", e)
            }
        }
        primeNotificationIcons()
        pickSession()

        if (link == null) {
            val l = LinkClient(linkCallbacks)
            link = l
            l.start(Prefs(this).carAddress)
        }
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        Log.w(TAG, "Servicio desconectado")
        CompanionState.log("Servicio desconectado")
        teardown()
        if (Build.VERSION.SDK_INT >= 24) {
            val c = me
            if (c != null) {
                try {
                    requestRebind(c)
                } catch (e: Exception) {
                    Log.e(TAG, "requestRebind falló", e)
                }
            }
        }
    }

    override fun onDestroy() {
        teardown()
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun teardown() {
        try {
            controller?.unregisterCallback(callback)
        } catch (e: Exception) {
            // ya estaba desregistrado
        }
        controller = null
        token = null
        if (sessionsRegistered) {
            try {
                msm?.removeOnActiveSessionsChangedListener(sessionsListener)
            } catch (e: Exception) {
                Log.e(TAG, "Error quitando el listener de sesiones", e)
            }
            sessionsRegistered = false
        }
        if (aclRegistered) {
            try {
                unregisterReceiver(aclReceiver)
            } catch (e: Exception) {
                // ya estaba desregistrado
            }
            aclRegistered = false
        }
        link?.stop()
        link = null
        lastSent = null
        art = null
        CompanionState.serviceConnected = false
        CompanionState.linkConnected = false
        instance = null
    }

    // ---------------------------------------------------------------- acciones desde la interfaz

    /** La pantalla elegida cambió. */
    fun applyTarget() {
        link?.setTarget(Prefs(this).carAddress)
    }

    /** Vuelve a enviar metadatos y carátula. */
    fun resend() {
        main.post { sendEverything() }
    }

    // ---------------------------------------------------------------- sesiones multimedia

    private fun pickSession() {
        val m = msm
        val c = me
        if (m == null || c == null) return
        val list: List<MediaController> = try {
            m.getActiveSessions(c)
        } catch (e: Exception) {
            Log.e(TAG, "Error en getActiveSessions", e)
            CompanionState.log("Error en getActiveSessions: ${e.javaClass.simpleName}")
            emptyList()
        }
        val candidates = list.filter { it.packageName != packageName }
        // Prioridad: 1) YouTube Music, 2) la que está reproduciendo, 3) la primera.
        var chosen: MediaController? = candidates.firstOrNull { it.packageName == Protocol.YTM_PACKAGE }
        if (chosen == null) {
            chosen = candidates.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
        }
        if (chosen == null) {
            chosen = candidates.firstOrNull()
        }

        val newToken = chosen?.sessionToken
        if (newToken != token) {
            try {
                controller?.unregisterCallback(callback)
            } catch (e: Exception) {
                // ya estaba desregistrado
            }
            controller = chosen
            token = newToken
            if (chosen != null) {
                try {
                    chosen.registerCallback(callback, main)
                } catch (e: Exception) {
                    Log.e(TAG, "No se pudo observar ${chosen.packageName}", e)
                }
                CompanionState.log("Sesión elegida: ${chosen.packageName}")
            } else {
                CompanionState.log("Sin sesiones multimedia")
            }
        }
        pushMeta(false)
        scheduleArt()
    }

    private fun buildMeta(): Meta {
        val c = controller ?: return Meta(false, false, "", "", "", 0L, 0L, 0, "")
        val md: MediaMetadata? = try {
            c.metadata
        } catch (e: Exception) {
            null
        }
        val st: PlaybackState? = try {
            c.playbackState
        } catch (e: Exception) {
            null
        }
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
            ?: ""
        if (md == null || title.isBlank()) return Meta(false, false, "", "", "", 0L, 0L, 0, c.packageName)

        val artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
            ?: ""
        val album = md.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""
        val duration = md.getLong(MediaMetadata.METADATA_KEY_DURATION)
        val playing = st?.state == PlaybackState.STATE_PLAYING

        var pos = st?.position ?: 0L
        if (pos < 0L) pos = 0L
        if (st != null && playing && st.lastPositionUpdateTime > 0L) {
            val speed = if (st.playbackSpeed <= 0f) 1f else st.playbackSpeed
            pos += ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * speed).toLong()
        }
        if (duration > 0L && pos > duration) pos = duration

        return Meta(true, playing, title, artist, album, duration, pos, Meta.keyOf(title, artist, album, duration), c.packageName)
    }

    /** Envía los metadatos a la pantalla solo si cambió algo relevante o la posición saltó (búsqueda). */
    private fun pushMeta(force: Boolean) {
        val m = buildMeta()
        updateState(m)

        val prev = lastSent
        var send = force || prev == null
        if (!send && prev != null) {
            if (prev.hasSession != m.hasSession || prev.playing != m.playing ||
                prev.trackKey != m.trackKey || prev.title != m.title ||
                prev.artist != m.artist || prev.album != m.album || prev.durationMs != m.durationMs
            ) {
                send = true
            } else if (m.hasSession) {
                val expected = if (prev.playing) {
                    prev.positionMs + (SystemClock.elapsedRealtime() - lastSentAt)
                } else {
                    prev.positionMs
                }
                if (Math.abs(m.positionMs - expected) > 2_000L) send = true
            }
        }
        if (!send) return

        lastSent = m
        lastSentAt = SystemClock.elapsedRealtime()
        if (art != null && art?.key != m.trackKey) {
            art = null
            CompanionState.artInfo = if (m.hasSession) "buscando…" else "sin carátula"
        }
        val l = link
        if (l != null && l.send(Protocol.T_META, m.encode())) {
            CompanionState.log("Enviado: ${m.title} — ${m.artist} (${if (m.playing) "reproduciendo" else "pausa"})")
        }
    }

    private fun updateState(m: Meta) {
        CompanionState.sessionPackage = m.sourcePackage
        CompanionState.title = m.title
        CompanionState.artist = m.artist
        CompanionState.album = m.album
        CompanionState.playing = m.playing
    }

    private fun sendEverything() {
        lastSent = null
        pushMeta(true)
        sendArt()
        scheduleArt()
    }

    private fun handleCommand(cmd: Int) {
        val c = controller
        if (c == null) {
            CompanionState.lastCommand = "orden $cmd ignorada: sin sesión"
            return
        }
        try {
            val tc = c.transportControls
            when (cmd) {
                Protocol.CMD_PLAY -> tc.play()
                Protocol.CMD_PAUSE -> tc.pause()
                Protocol.CMD_NEXT -> tc.skipToNext()
                Protocol.CMD_PREV -> tc.skipToPrevious()
                Protocol.CMD_TOGGLE -> if (CompanionState.playing) tc.pause() else tc.play()
            }
            CompanionState.lastCommand = "orden $cmd ejecutada en ${c.packageName}"
            CompanionState.log("Orden de la pantalla: $cmd")
        } catch (e: Exception) {
            Log.e(TAG, "Error ejecutando la orden $cmd", e)
            CompanionState.lastCommand = "orden $cmd falló: ${e.javaClass.simpleName}"
        }
    }

    // ---------------------------------------------------------------- carátula

    private fun scheduleArt() {
        val c = controller ?: return
        val sent = lastSent ?: return
        if (!sent.hasSession) return

        val key = sent.trackKey
        val have = art
        val haveRank = if (have != null && have.key == key) have.rank else 0
        if (haveRank >= ArtResolver.RANK_NATIVE) return

        val icon = notifIcons[c.packageName]
        // Evita lanzar la misma búsqueda varias veces seguidas.
        val sig = "$key|$haveRank|${icon != null}"
        val now = SystemClock.elapsedRealtime()
        if (sig == lastScheduleSig && now - lastScheduleAt < 3_000L) return
        lastScheduleSig = sig
        lastScheduleAt = now

        val md: MediaMetadata? = try {
            c.metadata
        } catch (e: Exception) {
            null
        }
        if (md == null) return
        val appCtx = applicationContext
        try {
            worker.execute {
                val r: ArtResolver.Result? = try {
                    ArtResolver.resolve(appCtx, md, icon, haveRank)
                } catch (e: Exception) {
                    Log.e(TAG, "Error buscando la carátula", e)
                    null
                }
                if (r != null) main.post { acceptArt(key, r) }
            }
        } catch (e: Exception) {
            Log.w(TAG, "No se pudo lanzar la búsqueda de carátula: ${e.message}")
        }
    }

    private fun acceptArt(key: Int, r: ArtResolver.Result) {
        val sent = lastSent
        if (sent == null || sent.trackKey != key) return // la canción ya cambió
        val cur = art
        if (cur != null && cur.key == key && cur.rank >= r.rank) return
        art = ArtState(key, r.rank, r.jpeg, r.source)
        CompanionState.artInfo = "${r.source} · ${r.jpeg.size / 1024} KB"
        CompanionState.log("Carátula lista: ${r.source}, ${r.jpeg.size / 1024} KB")
        sendArt()
    }

    private fun sendArt() {
        val a = art ?: return
        val sent = lastSent ?: return
        if (a.key != sent.trackKey) return
        val l = link ?: return
        if (l.send(Protocol.T_ART, Protocol.encodeArt(a.key, a.jpeg))) {
            CompanionState.log("Carátula enviada (${a.jpeg.size / 1024} KB)")
        }
    }

    // ---------------------------------------------------------------- icono de la notificación

    private fun primeNotificationIcons() {
        try {
            val active = activeNotifications
            if (active != null) {
                for (sbn in active) cacheIcon(sbn)
            }
        } catch (e: Exception) {
            Log.w(TAG, "No se pudieron leer las notificaciones activas: ${e.javaClass.simpleName}")
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        main.post {
            if (cacheIcon(sbn) && sbn.packageName == controller?.packageName) scheduleArt()
        }
    }

    /** Guarda el icono grande de una notificación multimedia (la carátula en la mayoría de reproductores). */
    private fun cacheIcon(sbn: StatusBarNotification): Boolean {
        val n: Notification = sbn.notification ?: return false
        val extras = n.extras ?: return false
        if (!extras.containsKey(Notification.EXTRA_MEDIA_SESSION)) return false
        val bmp = largeIconOf(n) ?: return false
        notifIcons[sbn.packageName] = bmp
        return true
    }

    @Suppress("DEPRECATION")
    private fun largeIconOf(n: Notification): Bitmap? {
        try {
            val icon: Icon? = n.getLargeIcon()
            if (icon != null) {
                val b = drawableToBitmap(icon.loadDrawable(this))
                if (b != null) return b
            }
        } catch (e: Exception) {
            Log.w(TAG, "Icono de notificación no legible: ${e.javaClass.simpleName}")
        }
        try {
            val b = n.extras?.getParcelable<Bitmap>(Notification.EXTRA_LARGE_ICON)
            if (b != null) return b
        } catch (e: Exception) {
            // el extra puede ser un Icon y no un Bitmap
        }
        return null
    }

    private fun drawableToBitmap(d: Drawable?): Bitmap? {
        if (d == null) return null
        if (d is BitmapDrawable) {
            val b = d.bitmap
            if (b != null) return b
        }
        val w = if (d.intrinsicWidth > 0) d.intrinsicWidth else 256
        val h = if (d.intrinsicHeight > 0) d.intrinsicHeight else 256
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        d.setBounds(0, 0, w, h)
        d.draw(canvas)
        return bmp
    }

    companion object {
        private const val TAG = "CarMusicCompanion"

        @Volatile
        var instance: CompanionService? = null
    }
}
