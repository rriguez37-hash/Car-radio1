package com.carmusic.companion

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

/** Pantalla de estado y configuración del Companion. Todo lo importante ocurre en CompanionService. */
class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var tvAccess: TextView
    private lateinit var tvService: TextView
    private lateinit var tvBluetooth: TextView
    private lateinit var tvCar: TextView
    private lateinit var tvLink: TextView
    private lateinit var tvTrack: TextView
    private lateinit var tvArt: TextView
    private lateinit var tvHelp: TextView

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1_000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)

        tvAccess = findViewById(R.id.tvAccess)
        tvService = findViewById(R.id.tvService)
        tvBluetooth = findViewById(R.id.tvBluetooth)
        tvCar = findViewById(R.id.tvCar)
        tvLink = findViewById(R.id.tvLink)
        tvTrack = findViewById(R.id.tvTrack)
        tvArt = findViewById(R.id.tvArt)
        tvHelp = findViewById(R.id.tvHelp)

        findViewById<Button>(R.id.btnAccess).setOnClickListener { openNotificationAccess() }
        findViewById<Button>(R.id.btnPick).setOnClickListener { pickCar() }
        findViewById<Button>(R.id.btnResend).setOnClickListener {
            CompanionService.instance?.resend()
            Toast.makeText(this, "Reenviando…", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnCopy).setOnClickListener { copyDiagnostics() }
    }

    override fun onStart() {
        super.onStart()
        // Android 12+: permiso de Bluetooth. Normalmente ya concedido (la app apunta a API 30).
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1)
        }
        // Si el acceso está concedido pero el servicio no está enlazado, se pide al sistema que lo reenlace.
        if (isListenerEnabled() && !CompanionState.serviceConnected && Build.VERSION.SDK_INT >= 24) {
            try {
                android.service.notification.NotificationListenerService.requestRebind(
                    ComponentName(this, CompanionService::class.java)
                )
            } catch (e: Exception) {
                Log.e(TAG, "requestRebind falló", e)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    private fun refresh() {
        val enabled = isListenerEnabled()
        tvAccess.text = "Acceso a notificaciones: " + if (enabled) "concedido" else "FALTA"
        tvAccess.setTextColor(if (enabled) Color.WHITE else Color.parseColor("#FF8A80"))
        tvService.text = "Servicio: " + if (CompanionState.serviceConnected) "activo" else "inactivo"

        val adapter: BluetoothAdapter? = try {
            BluetoothAdapter.getDefaultAdapter()
        } catch (e: Exception) {
            null
        }
        tvBluetooth.text = "Bluetooth: " + when {
            adapter == null -> "no disponible"
            adapter.isEnabled -> "encendido"
            else -> "apagado"
        }

        val addr = prefs.carAddress
        tvCar.text = if (addr == null) {
            "Pantalla del coche: sin elegir"
        } else {
            "Pantalla del coche: ${prefs.carName ?: "?"} ($addr)"
        }

        tvLink.text = "Enlace con la pantalla: ${CompanionState.linkStatus}"
        tvLink.setTextColor(if (CompanionState.linkConnected) Color.parseColor("#4CAF50") else Color.WHITE)

        val sb = StringBuilder()
        if (CompanionState.title.isBlank()) {
            sb.append("Canción: ninguna detectada")
            if (CompanionState.sessionPackage.isNotBlank()) {
                sb.append("\nSesión: ${CompanionState.sessionPackage}")
            }
        } else {
            sb.append("Canción: ${CompanionState.title}")
            sb.append("\nArtista: ${CompanionState.artist}")
            sb.append("\nÁlbum: ${CompanionState.album}")
            sb.append("\nEstado: " + if (CompanionState.playing) "reproduciendo" else "pausado")
            sb.append("\nSesión (paquete): ${CompanionState.sessionPackage}")
        }
        tvTrack.text = sb.toString()
        tvArt.text = "Carátula: ${CompanionState.artInfo}"

        tvHelp.text = when {
            !enabled ->
                "1. Pulsa «Acceso a notificaciones» y activa CarMusic Companion.\n" +
                    "   Si el interruptor está gris (Android 13+): Ajustes > Aplicaciones > CarMusic Companion > menú ⋮ > «Permitir ajustes restringidos» y repite.\n" +
                    "2. Elige la pantalla del coche.\n3. Reproduce música en YouTube Music."
            addr == null -> "Pulsa «Elegir pantalla del coche» y selecciona la unidad entre tus dispositivos emparejados."
            else -> ""
        }
    }

    // ---------------------------------------------------------------- acciones

    private fun openNotificationAccess() {
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } catch (e: Exception) {
            Log.e(TAG, "No se pudo abrir el acceso a notificaciones", e)
            Toast.makeText(this, "No se pudo abrir los ajustes", Toast.LENGTH_LONG).show()
        }
    }

    private fun pickCar() {
        val adapter: BluetoothAdapter? = try {
            BluetoothAdapter.getDefaultAdapter()
        } catch (e: Exception) {
            null
        }
        if (adapter == null || !adapter.isEnabled) {
            Toast.makeText(this, "Enciende el Bluetooth primero", Toast.LENGTH_LONG).show()
            return
        }
        val bonded: List<BluetoothDevice> = try {
            adapter.bondedDevices.toList()
        } catch (e: SecurityException) {
            Log.e(TAG, "Sin permiso para listar dispositivos emparejados", e)
            emptyList()
        }
        if (bonded.isEmpty()) {
            Toast.makeText(this, "No hay dispositivos emparejados. Empareja primero la pantalla del coche.", Toast.LENGTH_LONG).show()
            return
        }
        val labels = bonded.map { (it.name ?: "(sin nombre)") + "\n" + it.address }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Pantalla del coche")
            .setItems(labels) { _, which ->
                val d = bonded[which]
                prefs.carAddress = d.address
                prefs.carName = d.name
                CompanionService.instance?.applyTarget()
                refresh()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun copyDiagnostics() {
        val sb = StringBuilder()
        val version = try {
            packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: Exception) {
            "?"
        }
        sb.appendLine("CarMusic Companion $version · ${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        sb.appendLine("Acceso a notificaciones: " + if (isListenerEnabled()) "concedido" else "FALTA")
        sb.appendLine("Servicio: " + if (CompanionState.serviceConnected) "activo" else "inactivo")
        sb.appendLine("Pantalla: ${prefs.carName ?: "sin elegir"} (${prefs.carAddress ?: "-"})")
        sb.appendLine("Enlace: ${CompanionState.linkStatus}")
        sb.appendLine("Sesión: ${CompanionState.sessionPackage}")
        sb.appendLine("Canción: ${CompanionState.title} — ${CompanionState.artist} — ${CompanionState.album}")
        sb.appendLine("Carátula: ${CompanionState.artInfo}")
        sb.appendLine("Última orden: ${CompanionState.lastCommand}")
        sb.appendLine()
        sb.appendLine("── Registro ──")
        sb.append(CompanionState.logText())
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("CarMusic Companion diagnóstico", sb.toString()))
            Toast.makeText(this, "Diagnóstico copiado", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Log.e(TAG, "No se pudo copiar el diagnóstico", e)
        }
    }

    private fun isListenerEnabled(): Boolean = try {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        val me = ComponentName(this, CompanionService::class.java)
        flat?.split(":")?.any { ComponentName.unflattenFromString(it) == me } == true
    } catch (e: Exception) {
        Log.e(TAG, "Error comprobando el acceso a notificaciones", e)
        false
    }

    private companion object {
        const val TAG = "CarMusicCompanion"
    }
}
