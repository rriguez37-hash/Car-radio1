package com.carmusic.companion

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadata
import android.net.Uri
import android.os.Build
import android.util.Log
import com.carmusic.shared.Protocol
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Busca la mejor carátula disponible y la prepara para enviarla (JPEG, 512 px como máximo).
 *
 * Orden de preferencia (rango mayor = mejor):
 *  4  Bitmap dentro de MediaMetadata, o URI local legible (content://, file://...)
 *  3  URI https publicada por la app de música (se descarga)
 *  2  Icono grande de la notificación de reproducción
 */
object ArtResolver {
    private const val TAG = "CarMusicCompanion"

    const val RANK_NATIVE = 4
    const val RANK_HTTPS = 3
    const val RANK_NOTIF = 2

    class Result(val jpeg: ByteArray, val rank: Int, val source: String)

    private val bitmapKeys = listOf(
        "ALBUM_ART" to MediaMetadata.METADATA_KEY_ALBUM_ART,
        "ART" to MediaMetadata.METADATA_KEY_ART,
        "DISPLAY_ICON" to MediaMetadata.METADATA_KEY_DISPLAY_ICON
    )

    private val uriKeys = listOf(
        "ART_URI" to MediaMetadata.METADATA_KEY_ART_URI,
        "ALBUM_ART_URI" to MediaMetadata.METADATA_KEY_ALBUM_ART_URI,
        "DISPLAY_ICON_URI" to MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI
    )

    // URLs que fallaron hace poco: no se reintentan en cada cambio de metadatos.
    private val failedUrls = HashMap<String, Long>()

    /**
     * Devuelve una carátula mejor que [haveRank], o null si no hay ninguna mejor.
     * Puede tardar (descarga): llamar siempre desde un hilo de fondo.
     */
    fun resolve(ctx: Context, md: MediaMetadata, notifIcon: Bitmap?, haveRank: Int): Result? {
        if (haveRank < RANK_NATIVE) {
            for ((label, key) in bitmapKeys) {
                val bmp: Bitmap? = try {
                    md.getBitmap(key)
                } catch (e: Exception) {
                    null
                }
                if (bmp != null) {
                    val r = encode(bmp, RANK_NATIVE, "Bitmap de MediaMetadata ($label)")
                    if (r != null) return r
                }
            }
            for ((label, key) in uriKeys) {
                val s = md.getString(key)
                if (s.isNullOrBlank() || isRemote(s)) continue
                val bmp = loadLocal(ctx, s)
                if (bmp != null) {
                    val r = encode(bmp, RANK_NATIVE, "URI local ($label)")
                    if (r != null) return r
                }
            }
        }
        if (haveRank < RANK_HTTPS) {
            for ((label, key) in uriKeys) {
                val s = md.getString(key)
                if (s.isNullOrBlank() || !s.lowercase().startsWith("https://")) continue
                val bmp = download(s)
                if (bmp != null) {
                    val r = encode(bmp, RANK_HTTPS, "URI https ($label)")
                    if (r != null) return r
                }
            }
        }
        if (haveRank < RANK_NOTIF && notifIcon != null) {
            return encode(notifIcon, RANK_NOTIF, "Icono de la notificación")
        }
        return null
    }

    private fun isRemote(s: String): Boolean {
        val scheme = Uri.parse(s).scheme?.lowercase()
        return scheme == "http" || scheme == "https"
    }

    private fun loadLocal(ctx: Context, s: String): Bitmap? = try {
        ctx.contentResolver.openInputStream(Uri.parse(s))?.use { BitmapFactory.decodeStream(it) }
    } catch (e: Exception) {
        Log.w(TAG, "URI local no legible ($s): ${e.javaClass.simpleName}")
        null
    }

    private fun download(url: String): Bitmap? {
        val now = System.currentTimeMillis()
        synchronized(failedUrls) {
            val t = failedUrls[url]
            if (t != null && now - t < 60_000L) return null
        }
        var conn: HttpURLConnection? = null
        try {
            conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 5_000
            conn.readTimeout = 7_000
            conn.instanceFollowRedirects = true
            if (conn.responseCode != 200) throw IllegalStateException("HTTP ${conn.responseCode}")
            val bytes = conn.inputStream.use { readLimited(it, 3_000_000) }
                ?: throw IllegalStateException("imagen demasiado grande")
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (e: Exception) {
            Log.w(TAG, "No se pudo descargar la carátula: ${e.javaClass.simpleName}: ${e.message}")
            synchronized(failedUrls) { failedUrls[url] = now }
            return null
        } finally {
            conn?.disconnect()
        }
    }

    private fun readLimited(input: InputStream, limit: Int): ByteArray? {
        val bos = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        var total = 0
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            total += n
            if (total > limit) return null
            bos.write(buf, 0, n)
        }
        return bos.toByteArray()
    }

    /** Reduce a 512 px y comprime a JPEG. */
    private fun encode(src: Bitmap, rank: Int, source: String): Result? {
        try {
            var bmp = src
            if (Build.VERSION.SDK_INT >= 26 && bmp.config == Bitmap.Config.HARDWARE) {
                bmp = bmp.copy(Bitmap.Config.ARGB_8888, false) ?: return null
            }
            val longest = maxOf(bmp.width, bmp.height)
            if (longest <= 0) return null
            if (longest > Protocol.ART_MAX_PX) {
                val scale = Protocol.ART_MAX_PX.toFloat() / longest.toFloat()
                val w = maxOf(1, Math.round(bmp.width * scale))
                val h = maxOf(1, Math.round(bmp.height * scale))
                bmp = Bitmap.createScaledBitmap(bmp, w, h, true)
            }
            val bos = ByteArrayOutputStream()
            if (!bmp.compress(Bitmap.CompressFormat.JPEG, Protocol.ART_JPEG_QUALITY, bos)) return null
            return Result(bos.toByteArray(), rank, source)
        } catch (e: Exception) {
            Log.e(TAG, "No se pudo preparar la carátula", e)
            return null
        }
    }
}
