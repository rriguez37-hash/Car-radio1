package com.carmusic.companion

import android.content.Context
import android.content.SharedPreferences

/** Preferencias del Companion: qué dispositivo emparejado es la pantalla del coche. */
class Prefs(context: Context) {

    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("companion", Context.MODE_PRIVATE)

    var carAddress: String?
        get() = sp.getString("car_address", null)
        set(value) { sp.edit().putString("car_address", value).apply() }

    var carName: String?
        get() = sp.getString("car_name", null)
        set(value) { sp.edit().putString("car_name", value).apply() }
}
