package com.carmusic.companion

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.os.Build
import android.util.Log
import com.carmusic.shared.FrameIO
import com.carmusic.shared.Protocol
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.Closeable
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Cliente Bluetooth RFCOMM del teléfono. Intenta conectar con la pantalla del coche (dirección elegida
 * por el usuario) y reconecta solo con espera creciente (2 s hasta 60 s; además se reintenta al instante
 * cuando el teléfono se conecta por audio a la pantalla). Cuando conecta, la pantalla
 * recibe metadatos y carátula; las órdenes de la pantalla llegan por [Callbacks.onCommand].
 *
 * Los callbacks llegan desde un hilo propio, no del principal.
 */
class LinkClient(private val callbacks: Callbacks) {

    interface Callbacks {
        fun onStatus(text: String)
        fun onConnected()
        fun onDisconnected()
        fun onCommand(cmd: Int)
    }

    @Volatile private var running = false
    @Volatile private var address: String? = null
    @Volatile private var socket: BluetoothSocket? = null
    @Volatile private var out: DataOutputStream? = null
    private var thread: Thread? = null
    private var writer: ExecutorService? = null
    private val wake = LinkedBlockingQueue<Boolean>()

    fun start(deviceAddress: String?) {
        if (running) return
        running = true
        address = deviceAddress
        writer = Executors.newSingleThreadExecutor()
        val t = Thread({ loop() }, "carmusic-link")
        t.isDaemon = true
        thread = t
        t.start()
    }

    fun stop() {
        running = false
        closeQuietly(socket)
        wake.offer(true)
        thread?.interrupt()
        writer?.shutdownNow()
        writer = null
    }

    /** Cambia la pantalla de destino y fuerza un reintento inmediato. */
    fun setTarget(deviceAddress: String?) {
        address = deviceAddress
        closeQuietly(socket)
        wake.offer(true)
    }

    /** Reintenta ya (por ejemplo, cuando el teléfono acaba de conectarse a la pantalla). */
    fun nudge() {
        wake.offer(true)
    }

    fun isConnected(): Boolean = out != null

    /** Envía una trama. Devuelve false si no hay enlace. */
    fun send(type: Int, payload: ByteArray): Boolean {
        val o = out ?: return false
        val w = writer ?: return false
        try {
            w.execute {
                try {
                    FrameIO.write(o, type, payload)
                } catch (e: IOException) {
                    Log.w(TAG, "Error enviando trama $type: ${e.message}")
                    closeQuietly(socket)
                }
            }
        } catch (e: Exception) {
            return false
        }
        return true
    }

    // ---------------------------------------------------------------- bucle de conexión

    private fun loop() {
        var backoff = 2_000L
        while (running) {
            val addr = address
            val adapter: BluetoothAdapter? = try {
                BluetoothAdapter.getDefaultAdapter()
            } catch (e: Exception) {
                null
            }
            if (addr == null) {
                callbacks.onStatus("Elige la pantalla del coche")
                waitFor(5_000L)
                continue
            }
            if (adapter == null || !adapter.isEnabled) {
                callbacks.onStatus("Bluetooth apagado")
                waitFor(5_000L)
                continue
            }
            val device: BluetoothDevice = try {
                adapter.getRemoteDevice(addr)
            } catch (e: IllegalArgumentException) {
                callbacks.onStatus("Dirección de la pantalla no válida")
                waitFor(10_000L)
                continue
            }

            wake.clear()
            var sock: BluetoothSocket? = null
            try {
                callbacks.onStatus("Conectando con la pantalla…")
                val connected: BluetoothSocket = connectAny(device) // bloquea hasta conectar o fallar
                sock = connected
                socket = connected

                backoff = 2_000L
                val output = DataOutputStream(BufferedOutputStream(connected.outputStream))
                val input = DataInputStream(BufferedInputStream(connected.inputStream))
                out = output
                FrameIO.write(output, Protocol.T_HELLO, Protocol.hello(Build.MODEL ?: "Teléfono"))
                callbacks.onStatus("Conectado")
                callbacks.onConnected()

                while (running) {
                    val f = FrameIO.read(input)
                    if (f.type == Protocol.T_CMD && f.payload.isNotEmpty()) {
                        callbacks.onCommand(f.payload[0].toInt())
                    }
                }
            } catch (e: IOException) {
                Log.w(TAG, "Enlace: ${e.message}")
                callbacks.onStatus("Sin enlace: ${e.message ?: "error de Bluetooth"}")
            } catch (e: SecurityException) {
                Log.e(TAG, "Sin permiso Bluetooth", e)
                callbacks.onStatus("Sin permiso Bluetooth")
            } catch (e: Exception) {
                Log.e(TAG, "Error inesperado en el enlace", e)
                callbacks.onStatus("Error: ${e.javaClass.simpleName}")
            } finally {
                val wasConnected = out != null
                out = null
                socket = null
                closeQuietly(sock)
                if (wasConnected) callbacks.onDisconnected()
            }
            if (running) {
                waitFor(backoff)
                backoff = minOf(backoff * 2, 60_000L)
            }
        }
    }

    /**
     * Intenta primero el enlace seguro (dispositivos emparejados) y, si falla, el enlace sin cifrar,
     * que es el que acepta la pantalla en modo compatibilidad. Lanza la última excepción si ambos fallan.
     */
    private fun connectAny(device: BluetoothDevice): BluetoothSocket {
        var last: IOException? = null
        for (secure in booleanArrayOf(true, false)) {
            val s: BluetoothSocket = if (secure) {
                device.createRfcommSocketToServiceRecord(Protocol.SERVICE_UUID)
            } else {
                device.createInsecureRfcommSocketToServiceRecord(Protocol.SERVICE_UUID)
            }
            socket = s
            try {
                s.connect()
                return s
            } catch (e: IOException) {
                Log.w(TAG, "Conexión ${if (secure) "segura" else "sin cifrar"} fallida: ${e.message}")
                closeQuietly(s)
                last = e
                if (!running) break
            }
        }
        throw last ?: IOException("No se pudo conectar con la pantalla")
    }

    private fun waitFor(ms: Long) {
        try {
            wake.poll(ms, TimeUnit.MILLISECONDS)
        } catch (e: InterruptedException) {
            // stop() interrumpe la espera
        }
    }

    private fun closeQuietly(c: Closeable?) {
        try {
            c?.close()
        } catch (e: Exception) {
            // nada que hacer
        }
    }

    private companion object {
        const val TAG = "CarMusicCompanion"
    }
}
