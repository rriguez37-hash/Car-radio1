import com.android.build.gradle.internal.api.BaseVariantOutputImpl

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.carmusic.companion"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.carmusic.companion"
        minSdk = 23
        // Se mantiene en 30: con permisos Bluetooth clásicos (sin pedir BLUETOOTH_CONNECT en tiempo de ejecución).
        targetSdk = 30
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    // El APK siempre se llama CarMusic-Companion.apk
    applicationVariants.all {
        outputs.all {
            (this as BaseVariantOutputImpl).outputFileName = "CarMusic-Companion.apk"
        }
    }

    // Protocolo compartido con la app de la pantalla
    sourceSets.getByName("main").java.srcDir("../shared/src/main/kotlin")

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
}
